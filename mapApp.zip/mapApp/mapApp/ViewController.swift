//
//  ViewController.swift
//  mapApp
//
//  Created by Chayuth on 5/19/2559 BE.
//  Copyright © 2559 Chayuth. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController {
    
    //connect the MKMapView from Main.storyboard to let the code know that we use MKMapview in our application
    @IBOutlet weak var mapView: MKMapView!
    //connect the button to the code to use this button(for share location button)
    @IBOutlet weak var share: UIButton!
    //connect the button to the code to use this button(for navigation button)
    @IBOutlet weak var navigation: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //define the location of the temple 6 temples
        let location = CLLocationCoordinate2DMake(13.721042, 100.470203)
        //first set of number is latitude, second set of number is longitude
        let location1 = CLLocationCoordinate2DMake(13.913485, 100.421095)
        //first set of number is latitude, second set of number is longitude
        let location2 = CLLocationCoordinate2DMake(13.673739, 101.067081)
        //first set of number is latitude, second set of number is longitude
        let location3 = CLLocationCoordinate2DMake(13.738131, 100.514005)
        //first set of number is latitude, second set of number is longitude
        let location4 = CLLocationCoordinate2DMake(13.766598, 100.514043)
        //first set of number is latitude, second set of number is longitude
        let location5 = CLLocationCoordinate2DMake(13.739787, 100.491295)
        //first set of number is latitude, second set of number is longitude
        
        //define annotation1 to use variable in MKPointAnnotation. The MKPointAnnotation class defines a concrete annotation object located at a specified point. You can use this class, rather than define your own, in situations where all you want to do is associate a point on the map with a title.
        let annotation1 = MKPointAnnotation()
        let annotation2 = MKPointAnnotation()
        let annotation3 = MKPointAnnotation()
        let annotation4 = MKPointAnnotation()
        let annotation5 = MKPointAnnotation()
        let annotation6 = MKPointAnnotation()

        annotation1.coordinate = location
        //let "location" = annotation1.coordinate to pin in the map
        annotation1.title = "Wat Paknam"
        //set title of the location = "Wat Pkanam"
        annotation1.subtitle = "Located at 300 Ratchamongkolprasat Road, Pak Klong Bhasicharoen Sub-District, Bhasicharoen District, Bangkok 10160."
        //set subtitle of the this location
        
        annotation2.coordinate = location1
        annotation2.title = "Wat Leng Nei Yi 2"
        annotation2.subtitle = "Nonthaburi - Bangbua Tong District"
        
        annotation3.coordinate = location2
        annotation3.title = "Wat Sothornwararamworaviharn"
        annotation3.subtitle = "Amphoe Muang approximately, south of Sala Klang (the City Hall)."
        
        annotation4.coordinate = location3
        annotation4.title = "Wat Traimit"
        annotation4.subtitle = "Temple of the Golden Buddha"
        
        annotation5.coordinate = location4
        annotation5.title = "Wat Benchamabopit Dusit Wanaram"
        annotation5.subtitle = " Buddhist temple (wat) in the Dusit district of Bangkok, Thailand. Also known as the marble temple."
        
        annotation6.coordinate = location5
        annotation6.title = "Wat Kanlayanamit"
        annotation6.subtitle = "Wat Kanlayanamit is located on the Thon Buri bank of the Chao PhrayaRiver."
        
        //pin the red pin the map if not use mapView.addAnnotation(annotation..) the rep pin will not show in the map in our application.
        mapView.addAnnotation(annotation1)
        mapView.addAnnotation(annotation2)
        mapView.addAnnotation(annotation3)
        mapView.addAnnotation(annotation4)
        mapView.addAnnotation(annotation5)
        mapView.addAnnotation(annotation6)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func warn(sender: AnyObject) {
        let alert = UIAlertController(title: "Warning can not share your location", message: "You are not loging in to Facebbok", preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
                        self.presentViewController(alert, animated: true, completion: nil)
        
        
    }

}

