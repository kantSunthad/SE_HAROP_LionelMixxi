//
//  mapAppTests.swift
//  mapAppTests
//
//  Created by Chayuth on 5/19/2559 BE.
//  Copyright © 2559 Chayuth. All rights reserved.
//

import XCTest
import UIKit
import MapKit
import CoreLocation

@testable import mapApp

class mapAppTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        var calender
        var locale
        calendar = NSCalendar(identifier: NSCalendarIdentifierGregorian)
        locale = NSLocale(localeIdentifier: "th_TH")
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    func testUserService(){
        let playData = mapAppTests()
        playData.setUp()
        stopMeasuring()
    }
    
    func testLoad(){
        let store = CLLocation()
        CLLocation.init()
    }
    
    
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
